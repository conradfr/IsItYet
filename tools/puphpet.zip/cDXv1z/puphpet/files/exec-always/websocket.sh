#!/bin/bash

nohup php php -f /var/www/isityet/websocket/server.php &
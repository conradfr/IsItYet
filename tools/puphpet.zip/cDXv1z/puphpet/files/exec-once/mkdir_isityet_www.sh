#!/bin/bash

mkdir /var/www/isityet